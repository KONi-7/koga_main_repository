#include "DxLib.h"
#include <math.h>

enum e_But
{
    But_Down,
    But_Left,
    But_Right,
    But_Up,
    But_A,
    But_B,
    But_X,
    But_Y,
    But_L,
    But_R,
    But_Select,
    But_Start,
    But_L3,
    But_R3,
    But_Total
};

int Pad_Input;
int Pad_Count[e_But::But_Total];

bool Pad_Read()
{
    Pad_Input = GetJoypadInputState(DX_INPUT_PAD1);

    for (int b = 0; b < e_But::But_Total; b++)
    {
        if (Pad_Input & (1 << b))
        {
            Pad_Count[b] += 1;
        }
        else
        {
            Pad_Count[b] = 0;
        }
    }
    return false;
}

struct Rect
{
    int x;
    int y;
    int w;
    int h;
    bool flag;
};

#define BLOCK_NUM_X (16)
#define BLOCK_NUM_Y (3)

Rect Block[BLOCK_NUM_X][BLOCK_NUM_Y];
Rect Bar;

struct Circle
{
    int x;
    int y;
    int r;
};

struct Speed
{
    int x;
    int y;
};

Circle Ball;
Speed Ball_Speed;

void Game_Init()
{
    for (int y = 0; y < BLOCK_NUM_Y; y++)
    {
        for (int x = 0; x < BLOCK_NUM_X; x++)
        {
            Block[x][y] = { x * 100, 100 + y * 50, 100, 50, true };
        }
    }

    Bar = { 700, 700, 200, 30 };
    Ball = { 700, 500, 10 };
    // �{�[���̑��x�𔼕��ɂ���
    Ball_Speed = { 0, -5 }; // x�����̑��x�͕ύX�Ȃ�
}

bool HitJudge(Rect block, Circle ball)
{
    const double pi = 3.141592;
    double rad, x, y;
    int circum_x, circum_y;
    for (int i = 0; i < 360; i++)
    {
        rad = pi * i / 180;
        x = cos(rad);
        y = sin(rad);
        circum_x = ball.x + ball.r * x;
        circum_y = ball.y + ball.r * y;

        if (block.y <= circum_y &&
            circum_y <= block.y + block.h &&
            block.x <= circum_x &&
            circum_x <= block.x + block.w)
        {
            return true;
        }
    }
    return false;
}

void Game_Calculate()
{
    Pad_Read();

    // �L�[�{�[�h���͂ɂ��o�[�̈ړ�
    if (CheckHitKey(KEY_INPUT_A))
    {
        Bar.x -= 10; // A�L�[�ō��Ɉړ�
    }
    if (CheckHitKey(KEY_INPUT_D))
    {
        Bar.x += 10; // D�L�[�ŉE�Ɉړ�
    }

    // �o�[�̉�ʒ[�ł̐���
    if (Bar.x < 0)
    {
        Bar.x = 0;
    }
    if (Bar.x > 1600 - Bar.w)
    {
        Bar.x = 1600 - Bar.w;
    }

    // �{�[���Ƃ̓����蔻��
    for (int y = 0; y < BLOCK_NUM_Y; y++)
    {
        for (int x = 0; x < BLOCK_NUM_X; x++)
        {
            if (Block[x][y].flag == true &&
                HitJudge(Block[x][y], Ball) == true)
            {
                Ball_Speed.y = Ball_Speed.y * (-1);
                Block[x][y].flag = false;
                break;
            }
        }
    }

    // �o�[�Ƃ̓����蔻��
    if (HitJudge(Bar, Ball) == true)
    {
        int x = (Ball.x - (Bar.x + Bar.w / 2)) / 10;
        Ball_Speed.x = x;
        Ball_Speed.y = Ball_Speed.y * (-1);
    }

    // �{�[���̕ǔ���
    if (Ball.y < 0)
    {
        Ball_Speed.y = Ball_Speed.y * (-1);
    }

    if (Ball.x < 0 || Ball.x > 1600 - 2 * Ball.r)
    {
        Ball_Speed.x = Ball_Speed.x * (-1);
    }

    Ball.y = Ball.y + Ball_Speed.y;
    Ball.x = Ball.x + Ball_Speed.x;
}

void Game_Draw()
{
    for (int y = 0; y < BLOCK_NUM_Y; y++)
    {
        for (int x = 0; x < BLOCK_NUM_X; x++)
        {
            if (Block[x][y].flag == true)
            {
                switch (y)
                {
                case 0:
                    DrawBox(Block[x][y].x, Block[x][y].y,
                        Block[x][y].x + Block[x][y].w,
                        Block[x][y].y + Block[x][y].h,
                        GetColor(255, 0, 0), true);
                    break;
                case 1:
                    DrawBox(Block[x][y].x, Block[x][y].y,
                        Block[x][y].x + Block[x][y].w,
                        Block[x][y].y + Block[x][y].h,
                        GetColor(0, 255, 0), true);
                    break;
                case 2:
                    DrawBox(Block[x][y].x, Block[x][y].y,
                        Block[x][y].x + Block[x][y].w,
                        Block[x][y].y + Block[x][y].h,
                        GetColor(0, 255, 0), true);
                    break;
                }

                DrawBox(Block[x][y].x, Block[x][y].y,
                    Block[x][y].x + Block[x][y].w,
                    Block[x][y].y + Block[x][y].h,
                    GetColor(0, 0, 0), false);
            }
        }
    }

    DrawBox(Bar.x, Bar.y, Bar.x + Bar.w, Bar.y + Bar.h,
        GetColor(255, 255, 255), true);

    DrawCircle(Ball.x, Ball.y, Ball.r, GetColor(255, 0, 0), true);
}

bool Game_End()
{
    bool end = true;

    for (int y = 0; y < BLOCK_NUM_Y; y++)
    {
        for (int x = 0; x < BLOCK_NUM_X; x++)
        {
            if (Block[x][y].flag == true)
            {
                end = false;
            }
        }
    }

    if (Ball.y > 900)
    {
        end = true;
    }

    return end;
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    SetMainWindowText("�u���b�N����");
    SetWindowInitPosition(0, 0);
    SetGraphMode(1600, 900, 32);
    SetBackgroundColor(0, 0, 0);
    ChangeWindowMode(TRUE); // �E�B���h�E���[�h�ɕύX
    if (DxLib_Init() == -1) // DxLib�̏�����
    {
        return -1; // ���������s���͏I��
    }
    SetDrawScreen(DX_SCREEN_BACK);

    Game_Init();

    while (ProcessMessage() == 0)
    {
        ClearDrawScreen();

        Game_Calculate();
        Game_Draw();

        if (Game_End() == true)
        {
            Game_Init();
        }

        ScreenFlip();
    }

    DxLib_End(); // DxLib�̏I��

    return 0;
}
